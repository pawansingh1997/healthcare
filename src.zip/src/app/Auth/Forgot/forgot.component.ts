import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Service/Auth/auth.service';

class FogotModel
{
  name?: string;
  password?: string;
  token?: string
}

@Component({
  selector: 'forgot-app',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent implements OnInit,OnDestroy {

  errorMessage: string;

  forgot:FogotModel = new FogotModel();

  constructor(
    private router:Router,
    private authService: AuthService
  ) {
    this.errorMessage = '';
    localStorage.clear();
    this.authService.currentUserSubject.next(null as any);
  }

  ngOnInit(): void {

  }

  submit(): void {
    this.authService.Forogt(this.forgot)
    .subscribe((resp) => {
      alert("Password update successfully");
        this.router.navigate(["auth/login"]);
    },(err) => {
      this.errorMessage = err.error.Message;
    })
  }

  ngOnDestroy():void
  {
  }

}
