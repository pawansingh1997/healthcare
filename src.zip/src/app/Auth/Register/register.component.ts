import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Service/Auth/auth.service';

class RegisterModel {
  name?: string;
  password?: string;
  token?: string
}

@Component({
  selector: 'register-app',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit, OnDestroy {

  errorMessage: string;

  login: RegisterModel = new RegisterModel();

  constructor(
    private router: Router,
    private authService: AuthService
  ) {
    this.errorMessage = '';
    localStorage.clear();
    this.authService.currentUserSubject.next(null as any);
  }

  ngOnInit(): void {

  }

  submit(): void {
    this.login.name = this.login.name?.toLowerCase();
    this.authService.Register(this.login)
      .subscribe((resp) => {
        console.log(resp);
        this.router.navigate(["auth/login"]);
        alert("Registered Successfully")
      }, (err) => {
        console.log(err)
        this.errorMessage = err.error.Message;
      })
  }

  ngOnDestroy(): void {
  }

}
