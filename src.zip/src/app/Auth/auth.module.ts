import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AuthBaseComponent } from './auth.component';
import { AuthRoutingModule } from './auth.router.module';
import { ForgotComponent } from './Forgot/forgot.component';
import { LoginComponent } from './Login/login.component';
import { RegisterComponent } from './Register/register.component';


@NgModule({
   declarations: [AuthBaseComponent, LoginComponent , ForgotComponent, RegisterComponent],
   imports: [
       CommonModule,
       AuthRoutingModule,FormsModule]
})
export class AuthModule { }
