import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthBaseComponent } from './auth.component';
import { ForgotComponent } from './Forgot/forgot.component';
import { LoginComponent } from './Login/login.component';
import { RegisterComponent } from './Register/register.component';

const routes: Routes = [{
  path: '',
  component: AuthBaseComponent,
  children: [
    {
      path: 'login',
      component: LoginComponent,
    },
    {
      path: 'register',
      component: RegisterComponent,
    },
    {
      path: 'forgot',
      component: ForgotComponent,
    },
    {
      path: '',
      redirectTo: 'login',
      pathMatch: 'full',
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
