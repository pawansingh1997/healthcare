import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout-base',
  template: `<router-outlet></router-outlet>`,
})
export class CheckoutBaseComponent implements OnInit {
  ngOnInit(): void {
  }
}