import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/_Shared/shared.module';
import { CheckoutBaseComponent } from './checkout-base.component';
import { CheckoutRoutingModule } from './checkout.routing.module';
import { CreateCheckoutComponent } from './create/create-checkout.component';
import { CheckoutIndexComponent } from './index/checkout-index.component';

@NgModule({
  imports: [
    SharedModule,
    CheckoutRoutingModule,
  ],
  declarations: [
    CheckoutIndexComponent,
    CreateCheckoutComponent,
    CheckoutBaseComponent
  ],
})
export class CheckOutModule {
}
