import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { CheckoutBaseComponent } from './checkout-base.component';
import { CheckoutIndexComponent } from './index/checkout-index.component';
import { CreateCheckoutComponent } from './create/create-checkout.component';

const routes: Routes = [{
  path: '',
  component: CheckoutBaseComponent,
  children: [
    {
      path: 'index',
      component: CheckoutIndexComponent
    },
    {
      path: 'update/:id',
      component: CreateCheckoutComponent
    },
    {
      path: 'create',
      component: CreateCheckoutComponent
    }
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckoutRoutingModule {
}
