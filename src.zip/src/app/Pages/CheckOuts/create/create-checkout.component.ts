import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { CheckoutService } from 'src/app/Service/Checkout/checkout.service';
import { PatientService } from 'src/app/Service/Patient/patient.service';

class CheckoutReqModel {
  id?: number;
  patientId?: string;
  totalBillAmount?: number;
  status?: string;
  checkOut?: string;
}

@Component({
  selector: 'app-checkout-create',
  templateUrl: './create-checkout.component.html',
  styleUrls: ['./create-checkout.component.scss']
})
export class CreateCheckoutComponent implements OnInit {
  isEdit: boolean = false;
  minDate = new Date();
  


  checkoutReqModel: CheckoutReqModel = new CheckoutReqModel();

  constructor(
    private patientService: PatientService,
    private checkOutService: CheckoutService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public toaster: MatSnackBar,
  ) { }

  get(id: number) {
    this.checkOutService.Get(id)
      .subscribe((resp) => {
        console.log
        this.checkoutReqModel = resp;
      }, (err) => {
        this.toaster.open(err.error.Message, '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['red-snackbar'],
        });
      })
  }

  patientDropDownData:Array<{id:number,name: string}> = []

  prepareDropDown(isActive: any = null): void {
    let params = {
      isActive: isActive
    }
    this.patientService.Getall(params)
    .subscribe((resp) => {
      if(resp.length) {
        this.patientDropDownData =  resp.map((e:any) => ({id:e.id,name:e.name}))
      }
    })
  }


  ngOnInit(): void {
    
    this.activatedRoute.params
      .subscribe((params) => {
        if (params.id) {
          this.prepareDropDown();
          this.isEdit = true;
          this.get(params.id);
        } else {
          this.prepareDropDown(true);
        }
      });
  }
  update(): void {
    this.checkOutService.Update(this.checkoutReqModel)
      .subscribe((resp) => {
        this.toaster.open("Update Successfully", '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['green-snackbar'],
        });
        this.router.navigate(["/pages/checkout/index"])
      }, (err) => {
        this.toaster.open(err.error.Message, '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['red-snackbar'],
        });
      })
  }

  create(): void {
    this.checkOutService.Create(this.checkoutReqModel)
      .subscribe((resp) => {
        this.toaster.open("Create Successfully", '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['green-snackbar'],
        });
        this.router.navigate(["/pages/checkout/index"])
      }, (err) => {
        this.toaster.open(err.error.message, '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['red-snackbar'],
        });
      })
  }

  submit(): void {
    if (this.isEdit) {
      this.update()
    } else {
      this.create();
    }
  }
}