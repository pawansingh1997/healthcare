import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { PatientService } from 'src/app/Service/Patient/patient.service';

@Component({
  selector: 'app-checkout-index',
  templateUrl: './checkout-index.component.html',
  styleUrls: ['./checkout-index.component.scss']
})
export class CheckoutIndexComponent implements AfterViewInit, OnInit {
  displayedColumns: string[] = ['edit','id','name','gender','checkout','status','totalBillAmount'];

  dataSource = new MatTableDataSource<any>();

  constructor(
    public toaster: MatSnackBar,
    private router: Router,
    private patientService: PatientService
  ) {

  }

  goToEdit(element:any): void {
    this.router.navigate(['/pages/checkout/update/' + element?.checkoutData[0]?.id])
  }

  remove(element:any): void {
    const isConfirm = window.confirm("Are you sure want to delete ?");

    if(isConfirm) {
      this.patientService.Delete(element.id)
      .subscribe((resp) => {
        this.toaster.open("Deleted successfully", '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['red-snackbar'],
        });
        this.getAll();
      })
    }
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  @ViewChild(MatPaginator) paginator: MatPaginator | any;

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  getAll(): void {
    let params = {
      isActive: false
    }
    this.patientService.Getall(params)
    .subscribe((resp) => {
      this.dataSource = new MatTableDataSource<any>(resp);
      this.dataSource.paginator = this.paginator;
    })
  }

  ngOnInit(): void {
    this.getAll();
  }
}

