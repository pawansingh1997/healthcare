import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-index',
  templateUrl: './landing-index.component.html',
  styleUrls: ['./landing-index.component.scss']
})
export class LandingIndexComponent implements OnInit {
  ngOnInit(): void {
  }
}