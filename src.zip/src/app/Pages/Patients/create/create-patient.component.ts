import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from 'src/app/Service/Patient/patient.service';

class PatientReqModel {
  constructor() {
    this.gender = "Male"
  }
  id?: number;
  name?: string;
  gender?: string;
  dob?: string;
  checkIn?: string;
  contact?: string;
  address?: string;
  healthComplication?: string;
  status?: string;
  building?: string;
  roomType?: string;
  roomNo?: string;
}

@Component({
  selector: 'app-patient-create',
  templateUrl: './create-patient.component.html',
  styleUrls: ['./create-patient.component.scss']
})
export class CreatePatientComponent implements OnInit {
  isEdit: boolean = false;
  maxDate = new Date();

  patientReqModel: PatientReqModel = new PatientReqModel();

  constructor(
    private patientService: PatientService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public toaster: MatSnackBar,
  ) { }

  get(id: number) {
    this.patientService.Get(id)
      .subscribe((resp) => {
        console.log
        this.patientReqModel = resp;
      }, (err) => {
        this.toaster.open(err.error.Message, '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['red-snackbar'],
        });
      })
  }


  ngOnInit(): void {
    this.activatedRoute.params
      .subscribe((params) => {
        if (params.id) {
          this.isEdit = true;
          this.get(params.id);
        }
      });
  }
  update(): void {
    this.patientService.Update(this.patientReqModel)
      .subscribe((resp) => {
        this.toaster.open("Update Successfully", '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['green-snackbar'],
        });
        this.router.navigate(["/pages/patients/index"])
      }, (err) => {
        this.toaster.open(err.error.Message, '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['red-snackbar'],
        });
      })
  }

  create(): void {
    this.patientService.Create(this.patientReqModel)
      .subscribe((resp) => {
        this.toaster.open("Create Successfully", '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['green-snackbar'],
        });
        this.router.navigate(["/pages/patients/index"])
      }, (err) => {
        this.toaster.open(err.error.message, '', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['red-snackbar'],
        });
      })
  }

  submit(): void {
    if (this.isEdit) {
      this.update()
    } else {
      this.create();
    }
  }
}