import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patines-base',
  template: `<router-outlet></router-outlet>`,
})
export class PatientBaseComponent implements OnInit {
  ngOnInit(): void {
  }
}