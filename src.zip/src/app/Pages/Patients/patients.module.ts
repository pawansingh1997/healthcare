import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/_Shared/shared.module';
import { CreatePatientComponent } from './create/create-patient.component';
import { PatientIndexComponent } from './index/patient-index.component';
import { PatientBaseComponent } from './patients-base.component';
import { PatientRoutingModule } from './patients.routing.module';


@NgModule({
  imports: [
    SharedModule,
    PatientRoutingModule,
  ],
  declarations: [
    PatientIndexComponent,
    CreatePatientComponent,
    PatientBaseComponent
  ],
})
export class PatientModule {
}
