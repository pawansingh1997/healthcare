import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { PatientBaseComponent } from './patients-base.component';
import { PatientIndexComponent } from './index/patient-index.component';
import { CreatePatientComponent } from './create/create-patient.component';

const routes: Routes = [{
  path: '',
  component: PatientBaseComponent,
  children: [
    {
      path: 'index',
      component: PatientIndexComponent
    },
    {
      path: 'update/:id',
      component: CreatePatientComponent
    },
    {
      path: 'create',
      component: CreatePatientComponent
    }
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PatientRoutingModule {
}
