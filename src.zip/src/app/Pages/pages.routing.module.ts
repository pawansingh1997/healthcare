import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { PagesComponent } from './pages-base.component';

const routes: Routes = [{
  path: '',
  component: PagesComponent,
  children: [
    {
      path: 'landing',
      loadChildren: () => import('./Landing/landing.module')
        .then(m => m.LandingModule),
    },
    {
      path: 'patients',
      loadChildren: () => import('./Patients/patients.module')
        .then(m => m.PatientModule),
    },
    {
      path: 'checkout',
      loadChildren: () => import('./CheckOuts/checkout.module')
        .then(m => m.CheckOutModule),
    },
    {
      path: '',
      redirectTo: 'pages/landing',
      pathMatch: 'full',
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {
}
