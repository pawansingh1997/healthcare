import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  
    constructor(private http:HttpClient) {}

  Create(data:any) {
    return this.http.post<any>(`${environment.apiUrl}/api/Patient/PatientRegistration`,data);
  }

  Update(data:any) {
    return this.http.put<any>(`${environment.apiUrl}/api/Patient/PatientDetailsUpdate`,data);
  }

  Getall(data:any) {
    return this.http.get<any>(`${environment.apiUrl}/api/Patient/GetAll`,{
        params: new HttpParams()
        .append('isActive',String(data.isActive))
    });
  }

  Get(id:number) {
    return this.http.get<any>(`${environment.apiUrl}/api/Patient/Get/${id}`);
  }

  Delete(id:number) {
    return this.http.delete<any>(`${environment.apiUrl}/api/Patient/Delete/${id}`);
  }


}
