import { Component, OnInit } from '@angular/core';
// @ts-ignore
import * as d3 from 'd3-sankey'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  ngOnInit(): void {
  }
}